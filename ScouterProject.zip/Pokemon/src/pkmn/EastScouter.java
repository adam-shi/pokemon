/* 
 * Takes a username as input and outputs all teams used into an output 
 * file, separating by metagame.
 * 
 * Output can be used to generate counterteams with program by Stathakis
 * (hopefully).
 * 
 * Written by Adam Shi (uragg).
 *  */

package pkmn;

import org.openqa.selenium.*;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.firefox.*;
import org.openqa.selenium.remote.RemoteWebDriver;

import java.io.*;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.*;
import java.util.*;
import java.util.regex.Pattern;

public class EastScouter {

	public static final String psURL = "http://replay.pokemonshowdown.com";
	
	public static void main(String[] args) throws IOException, InterruptedException {
		Charset cs = Charset.forName("UTF-8");
		
		Path inputPath = Paths.get("input");
		List<String> usernameList = Files.readAllLines(inputPath, cs);
		
		RemoteWebDriver driver = new FirefoxDriver();
		JavascriptExecutor jse = (JavascriptExecutor) driver;
		
		// launch Firefox and go to replay site.
		driver.get(psURL);
		driver.manage().window().maximize();
		
		for (String username : usernameList) {
			System.out.println("looking for teams for " + username);
			
			String outputFile = username + "-teams.txt";
			Path p1 = Paths.get(outputFile);
			
			Files.deleteIfExists(p1);
			Files.createFile(p1);
			
			// inputs username input into search box.
			WebElement usernameElement = driver.findElementByName("user");
			usernameElement.sendKeys(username);
			
			// clicks "Search" button to search for replays by user.
			WebElement buttonElement = driver.findElement(By.xpath("//button[@type='submit']"));
			buttonElement.click();
		
			Thread.sleep(1000);
			
			// clicks "More" repeatedly to get all replays to show up.
			jse.executeScript("scroll(0, 400)");
			
			while (true) {
				try {
					WebElement moreButton = driver.findElement(By.xpath("//button[@name='moreResults']"));
					moreButton.click();
					Thread.sleep(500);
					jse.executeScript("scroll(0, 600)");
				} catch (NoSuchElementException e) {
					break;
				}
			}
				
			// find OU games to look at teams.
			// battles uploaded via smogtours.
			List<WebElement> battles = driver.findElements(By.cssSelector("a[href*='-ou-']"));
			// battles not from smogtours but uploaded.
			List<WebElement> otherBattles = driver.findElements(By.cssSelector("a[href^='/ou-']"));
				
			List<WebElement> teams;
			List<String> teamList = new ArrayList<String>();
			WebElement date;
			int numDate;
			
			try {
				// loop over each OU battle to find teams.
				for (WebElement battle : battles) {
					battle.click();
					
					Thread.sleep(800);
					
					teams = driver.findElements(By.cssSelector("div[class='chat']"));
					
					for (WebElement team : teams) {
						String teamText = team.getText();
						if (teamText.toUpperCase().startsWith(username.toUpperCase() + "'S TEAM")) {					
							String teamOnly = teamText.substring(username.length() + 9, teamText.length());
							
							teamList.add(teamOnly);
							break;
						}
						
					}
					
					Thread.sleep(1000);
					
					date = driver.findElement(By.cssSelector("small[class='uploaddate']"));
					numDate = Integer.parseInt(date.getAttribute("data-timestamp"));
					
					if (numDate < 1451590105) {
						break;
					}
					
				}
			} catch (Exception e) {
				// do nothing
			}
			
			try {
				for (WebElement battle : otherBattles) {
					battle.click();
					
					Thread.sleep(800);
					
					teams = driver.findElements(By.cssSelector("div[class='chat']"));
					
					for (WebElement team : teams) {
						String teamText = team.getText();
						if (teamText.toUpperCase().startsWith(username.toUpperCase() + "'S TEAM")) {					
							String teamOnly = teamText.substring(username.length() + 9, teamText.length());
							
							teamList.add(teamOnly);
							break;
						}
						
					}
					
					Thread.sleep(1000);
					
					date = driver.findElement(By.cssSelector("small[class='uploaddate']"));
					numDate = Integer.parseInt(date.getAttribute("data-timestamp"));
					
					if (numDate < 1451590105) {
						break;
					}
				}
			} catch (Exception e) {
				// do nothing
			}
			
			Files.write(p1, teamList, cs, StandardOpenOption.APPEND);
			
			driver.navigate().to(psURL);
		}
		
		driver.quit();
	}

}
